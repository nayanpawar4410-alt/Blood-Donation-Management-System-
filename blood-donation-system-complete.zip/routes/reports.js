const express = require("express");
const pool = require("../db/connection");
const { requireLogin } = require("../middleware/auth");
const router = express.Router();

router.get("/summary", requireLogin, async (req, res) => {
  try {
    const [[donors]] = await pool.query("SELECT COUNT(*) AS total FROM donors");
    const [[requests]] = await pool.query("SELECT COUNT(*) AS total FROM blood_requests");
    const [[openRequests]] = await pool.query("SELECT COUNT(*) AS total FROM blood_requests WHERE status IN ('Open','Contacting')");
    const [groups] = await pool.query("SELECT blood_group, COUNT(*) AS total FROM donors GROUP BY blood_group ORDER BY blood_group");
    res.json({
      donors: donors.total,
      requests: requests.total,
      open_requests: openRequests.total,
      blood_groups: groups
    });
  } catch (err) {
    res.status(500).json({ message: "Could not generate report", error: err.message });
  }
});

router.get("/audit", requireLogin, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT a.*, u.username FROM audit_logs a
       LEFT JOIN users u ON a.user_id=u.user_id
       ORDER BY a.log_id DESC LIMIT 200`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Could not fetch audit logs", error: err.message });
  }
});

module.exports = router;