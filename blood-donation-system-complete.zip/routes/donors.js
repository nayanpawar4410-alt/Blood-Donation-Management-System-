const express = require("express");
const pool = require("../db/connection");
const { requireLogin, requireAdmin } = require("../middleware/auth");
const router = express.Router();

async function audit(req, action, entityId, details) {
  await pool.query(
    "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details) VALUES (?, ?, 'donor', ?, ?)",
    [req.session.user.user_id, action, entityId || null, details || ""]
  );
}

router.post("/", requireLogin, async (req, res) => {
  try {
    const { full_name, phone, email, blood_group, city_area, last_donation_date, consent_to_contact } = req.body;
    if (!full_name || !phone || !blood_group || !city_area) return res.status(400).json({ message: "Required fields are missing" });

    const [result] = await pool.query(
      `INSERT INTO donors (full_name, phone, email, blood_group, city_area, last_donation_date, consent_to_contact)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [full_name, phone, email || null, blood_group, city_area, last_donation_date || null, consent_to_contact !== false]
    );
    await audit(req, "CREATE", result.insertId, `Donor ${full_name} created`);
    res.json({ message: "Donor added", donor_id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Could not add donor", error: err.message });
  }
});

router.get("/", requireLogin, async (req, res) => {
  try {
    const { blood_group, city_area, q } = req.query;
    let sql = "SELECT * FROM donors WHERE 1=1";
    const params = [];
    if (blood_group) { sql += " AND blood_group = ?"; params.push(blood_group); }
    if (city_area) { sql += " AND city_area LIKE ?"; params.push(`%${city_area}%`); }
    if (q) { sql += " AND (full_name LIKE ? OR phone LIKE ? OR email LIKE ?)"; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
    sql += " ORDER BY donor_id DESC";
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Could not fetch donors", error: err.message });
  }
});

router.put("/:id", requireLogin, async (req, res) => {
  try {
    const { full_name, phone, email, blood_group, city_area, last_donation_date, consent_to_contact } = req.body;
    await pool.query(
      `UPDATE donors SET full_name=?, phone=?, email=?, blood_group=?, city_area=?, last_donation_date=?, consent_to_contact=? WHERE donor_id=?`,
      [full_name, phone, email || null, blood_group, city_area, last_donation_date || null, consent_to_contact !== false, req.params.id]
    );
    await audit(req, "UPDATE", req.params.id, "Donor updated");
    res.json({ message: "Donor updated" });
  } catch (err) {
    res.status(500).json({ message: "Could not update donor", error: err.message });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    await pool.query("DELETE FROM donors WHERE donor_id=?", [req.params.id]);
    await audit(req, "DELETE", req.params.id, "Donor deleted");
    res.json({ message: "Donor deleted" });
  } catch (err) {
    res.status(500).json({ message: "Could not delete donor", error: err.message });
  }
});

module.exports = router;