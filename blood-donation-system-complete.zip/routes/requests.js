const express = require("express");
const pool = require("../db/connection");
const { requireLogin } = require("../middleware/auth");
const router = express.Router();

async function audit(req, action, entityId, details) {
  await pool.query(
    "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details) VALUES (?, ?, 'blood_request', ?, ?)",
    [req.session.user.user_id, action, entityId || null, details || ""]
  );
}

router.post("/", requireLogin, async (req, res) => {
  try {
    const { requester_name, contact_phone, blood_group, units_requested, facility_name, area, urgency } = req.body;
    if (!requester_name || !contact_phone || !blood_group || !units_requested || !facility_name || !area) {
      return res.status(400).json({ message: "Required fields are missing" });
    }
    const [result] = await pool.query(
      `INSERT INTO blood_requests (requester_name, contact_phone, blood_group, units_requested, facility_name, area, urgency)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [requester_name, contact_phone, blood_group, units_requested, facility_name, area, urgency || "Normal"]
    );
    await audit(req, "CREATE", result.insertId, `Blood request created`);
    res.json({ message: "Request added", request_id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Could not add request", error: err.message });
  }
});

router.get("/", requireLogin, async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM blood_requests ORDER BY request_id DESC");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Could not fetch requests", error: err.message });
  }
});

router.patch("/:id/status", requireLogin, async (req, res) => {
  try {
    const allowed = ["Open", "Contacting", "Fulfilled", "Cancelled"];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid status" });
    await pool.query("UPDATE blood_requests SET status=? WHERE request_id=?", [req.body.status, req.params.id]);
    await audit(req, "STATUS_UPDATE", req.params.id, `Status changed to ${req.body.status}`);
    res.json({ message: "Status updated" });
  } catch (err) {
    res.status(500).json({ message: "Could not update status", error: err.message });
  }
});

module.exports = router;