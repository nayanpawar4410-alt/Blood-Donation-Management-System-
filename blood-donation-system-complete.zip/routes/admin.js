const express = require("express");
const bcrypt = require("bcryptjs");
const pool = require("../db/connection");
const { requireAdmin } = require("../middleware/auth");
const router = express.Router();

router.get("/users", requireAdmin, async (req, res) => {
  const [rows] = await pool.query("SELECT user_id, username, role, created_at FROM users ORDER BY user_id DESC");
  res.json(rows);
});

router.post("/users", requireAdmin, async (req, res) => {
  try {
    const { username, password, role } = req.body;
    if (!username || !password || !["admin","staff"].includes(role)) {
      return res.status(400).json({ message: "Username, password and valid role are required" });
    }
    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
      [username, hash, role]
    );
    res.json({ message: "User created", user_id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Could not create user", error: err.message });
  }
});

router.delete("/users/:id", requireAdmin, async (req, res) => {
  try {
    if (Number(req.params.id) === Number(req.session.user.user_id)) {
      return res.status(400).json({ message: "You cannot delete your own account" });
    }
    await pool.query("DELETE FROM users WHERE user_id=?", [req.params.id]);
    res.json({ message: "User deleted" });
  } catch (err) {
    res.status(500).json({ message: "Could not delete user", error: err.message });
  }
});

module.exports = router;