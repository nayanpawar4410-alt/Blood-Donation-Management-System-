const express = require("express");
const bcrypt = require("bcryptjs");
const pool = require("../db/connection");
const router = express.Router();

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ message: "Username and password are required" });

    const [rows] = await pool.query("SELECT user_id, username, password_hash, role FROM users WHERE username = ?", [username]);
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    req.session.user = {
      user_id: rows[0].user_id,
      username: rows[0].username,
      role: rows[0].role
    };
    res.json({ message: "Login successful", user: req.session.user });
  } catch (err) {
    res.status(500).json({ message: "Login error", error: err.message });
  }
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => res.json({ message: "Logged out" }));
});

router.get("/me", (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Not logged in" });
  res.json({ user: req.session.user });
});

module.exports = router;