document.getElementById("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const res = await fetch("/api/auth/login", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:username.value,password:password.value})});
  const data = await res.json();
  if(res.ok) location.href="dashboard.html"; else msg.textContent=data.message;
});